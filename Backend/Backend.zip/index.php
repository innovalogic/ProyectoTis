<?php
// Verificar que el servidor esté funcionando
echo "¡Bienvenido a tu backend en PHP!";